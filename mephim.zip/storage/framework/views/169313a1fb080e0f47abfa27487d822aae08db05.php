
<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Movie
                            <small>Edit</small>
                        </h1>
                        <?php if(count($errors)): ?>
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($err); ?> <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- /.col-lg-12 -->
                    <div class="col-lg-7" style="padding-bottom:120px">
                        <form action="<?php echo e(route('admin.movie.update',$movie->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="form-group">
                                <label >Category</label>
                                <select class="form-control" name="category_id">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php if($movie->category_id == $category->id): ?> selected <?php endif; ?> > <?php echo e($category->title); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label >Genre</label>
                                <select class="form-control" name="genre_id">
                                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($genre->id); ?>" <?php if($movie->genre_id == $genre->id): ?> selected <?php endif; ?>><?php echo e($genre->title); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label >Country</label>
                                <select class="form-control" name="country_id">
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>" <?php if($movie->country_id == $country->id): ?> selected <?php endif; ?>><?php echo e($country->title); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Title</label>
                                <input class="form-control" name="title" value="<?php echo e($movie->title); ?>" />
                            </div>
                            <div class="form-group">
                                <label>Image</label>
                                <input type="file" class="form-control" name="image" />
                                <img src="<?php echo e($movie->urlImage()); ?>" width="50px" height="auto">
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <textarea id="demo" name="description" class="ckeditor"><?php echo e($movie->description); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Release year</label>
                                <input class="form-control" name="release_year" value="<?php echo e($movie->release_year); ?>" />
                            </div>
                            <div class="form-group">
                                <label>Movie Status</label>
                                <label class="radio-inline">
                                    <input name="status" <?php if($movie->status == 1): ?> checked <?php endif; ?> type="radio">Visible
                                </label>
                                <label class="radio-inline">
                                    <input name="status" <?php if($movie->status == 0): ?> checked <?php endif; ?> type="radio">Invisible
                                </label>
                            </div>
                            <div class="form-group">
                                <label>New Movie</label>
                                <label class="radio-inline">
                                    <input name="movie_new" <?php if($movie->movie_new == 1): ?> checked <?php endif; ?> type="radio">New
                                </label>
                                <label class="radio-inline">
                                    <input name="movie_new"  <?php if($movie->movie_new == 0): ?> checked <?php endif; ?> type="radio">Old
                                </label>
                            </div>
                            <div class="form-group">
                                <label>Highlight Movie</label>
                                <label class="radio-inline">
                                    <input name="movie_highlight"  <?php if($movie->movie_highlight == 1): ?> checked <?php endif; ?> type="radio">Highlight
                                </label>
                                <label class="radio-inline">
                                    <input name="movie_highlight"  <?php if($movie->movie_highlight == 0): ?> checked <?php endif; ?> type="radio">Normal
                                </label>
                            </div>
                            <button type="submit" class="btn btn-default">Update</button>
                            
                        <form>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mephim\resources\views/admin/movie/edit.blade.php ENDPATH**/ ?>