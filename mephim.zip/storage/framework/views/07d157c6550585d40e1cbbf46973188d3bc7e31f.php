
<?php $__env->startSection('title'); ?>
Movie Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Movie
                            <small>Add</small>
                        </h1>
                        <?php if(count($errors)): ?>
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($err); ?> <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- /.col-lg-12 -->
                    <div class="col-lg-7" style="padding-bottom:120px">
                        <form action="<?php echo e(route('admin.movie.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label >Category</label>
                                <select class="form-control" name="category_id">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label >Genre</label>
                                <select class="form-control" name="genre_id">
                                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->title); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label >Country</label>
                                <select class="form-control" name="country_id">
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->title); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Title</label>
                                <input class="form-control" name="title" placeholder="Please Enter Username" />
                            </div>
                            <div class="form-group">
                                <label>Image</label>
                                <input type="file" class="form-control" name="image" />
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <textarea id="demo" name="description" class="ckeditor"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Release year</label>
                                <input class="form-control" name="release_year" placeholder="Please Enter release year" />
                            </div>
                            <div class="form-group">
                                <label>Movie Status</label>
                                <label class="radio-inline">
                                    <input name="status" value="1" checked="" type="radio">Visible
                                </label>
                                <label class="radio-inline">
                                    <input name="status" value="0" type="radio">Invisible
                                </label>
                            </div>
                            <div class="form-group">
                                <label>New Movie</label>
                                <label class="radio-inline">
                                    <input name="movie_new" value="1" checked="" type="radio">New
                                </label>
                                <label class="radio-inline">
                                    <input name="movie_new" value="0" type="radio">Old
                                </label>
                            </div>
                            <div class="form-group">
                                <label>Highlight Movie</label>
                                <label class="radio-inline">
                                    <input name="movie_highlight" value="1" checked="" type="radio">Highlight
                                </label>
                                <label class="radio-inline">
                                    <input name="movie_highlight" value="0" type="radio">Normal
                                </label>
                            </div>
                            <button type="submit" class="btn btn-default">Country Add</button>
                            
                        <form>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mephim\resources\views/admin/movie/create.blade.php ENDPATH**/ ?>