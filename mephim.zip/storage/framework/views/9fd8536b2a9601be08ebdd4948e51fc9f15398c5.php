
<?php $__env->startSection('title'); ?>
List Genre
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper" >
   
            <div class="container-fluid" >
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Genre
                            <small>List</small>
                        </h1>
                      
                    <?php if(session('success')): ?>
                        <p class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </p>
                    <?php endif; ?>
                    </div>
                   
                    <!-- /.col-lg-12 -->
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr align="center">
                                <th>ID</th>
                                <th>title</th>
                                
                                <th>description</th>
                                <th>slug</th>
                                <th>status</th>
                                <th>Delete</th>
                                <th>Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX" align="center">
                                <td><?php echo e($genre->id); ?></td>
                                <td><?php echo e($genre->title); ?></td>
                                <td><?php echo e($genre->description); ?></td>
                                <td><?php echo e($genre->slug); ?></td>
                                <td><?php echo e($genre->status == 0 ? "invisible" : "visible"); ?></td>
                                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="<?php echo e(route('admin.genre.delete',$genre->id)); ?>"> Delete</a></td>
                                
                                <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="<?php echo e(route('admin.genre.edit',$genre->id)); ?>">Edit</a></td>
                            </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
           
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mephim\resources\views/admin/genre/list.blade.php ENDPATH**/ ?>