

<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<h3 class="section-title"><span>Results</span></h3>
         <div class="row container" id="wrapper">
            <main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
             
               <section id="halim-advanced-widget-2">
                 
                  <div id="halim-advanced-widget-2-ajax-box" class="halim_box">
                  <?php $__currentLoopData = $results->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <article class="col-md-3 col-sm-3 col-xs-6 thumb grid-item post-37606">
                        <div class="halim-item">
                           <a class="halim-thumb" href="<?php echo e(route('web.movie',$res->slug)); ?>">
                              <figure><img class="lazy img-responsive" src="<?php echo e($res->urlImage()); ?>" alt="BẠN CÙNG PHÒNG CỦA TÔI LÀ GUMIHO" title="<?php echo e($res->title); ?>"></figure>
                              <span class="status">TẬP 15</span><span class="episode"><i class="fa fa-play" aria-hidden="true"></i>Vietsub</span> 
                              <div class="icon_overlay"></div>
                              <div class="halim-post-title-box">
                                 <div class="halim-post-title ">
                                    <p class="entry-title"><?php echo e($res->title); ?></p>
                                    <p class="original_title">My Roommate Is a Gumiho</p>
                                 </div>
                              </div>
                           </a>
                        </div>
                     </article>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
               </section>
               <div class="clearfix"></div>
            </main>
           
         </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mephim\resources\views/pages/search.blade.php ENDPATH**/ ?>