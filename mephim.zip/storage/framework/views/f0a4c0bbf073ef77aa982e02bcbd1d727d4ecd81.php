
<?php $__env->startSection('title'); ?>
Movie List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper" >
   
            <div class="container-fluid" >
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Movie
                            <small>List</small>
                        </h1>
                      
                    <?php if(session('success')): ?>
                        <p class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </p>
                    <?php endif; ?>
                    </div>
                   
                    <!-- /.col-lg-12 -->
                    <table class="table table-striped table-bordered table-hover" id="myTable">
                        <thead>
                            <tr align="center">
                                <th>ID</th>
                                <th>title</th>
                                <th>image</th>
                                <th>Category</th>
                                <th>Genre</th>
                                <th>Country</th>
                                <th>status</th>
                                <th>views count</th>
                                <th>New/Old</th>
                                <th>Normal/Highlight</th>
                                <th>release_year</th>
                                <th>Delete</th>
                                <th>Edit</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX" align="center">
                                <td><?php echo e($movie->id); ?></td>
                                <td><?php echo e($movie->title); ?></td>
                                <td><img src="<?php echo e($movie->urlImage()); ?>" width="50px" height="auto"></td>
                                <td><?php echo e($movie->category->title); ?></td>
                                <td><?php echo e($movie->genre->title); ?></td>
                                <td><?php echo e($movie->country->title); ?></td>
                                <td><?php echo e($movie->status == 0 ? "invisible" : "visible"); ?></td>
                                <td><?php echo e($movie->views_count); ?></td>
                                <td><?php echo e($movie->movie_new == 0 ? "old" : "new"); ?></td>
                                <td><?php echo e($movie->movie_highlight == 0 ? "normal" : "highlight"); ?></td>
                                <td><?php echo e($movie->release_year); ?></td>
                                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="<?php echo e(route('admin.movie.delete',$movie->id)); ?>"> Delete</a></td>
                                
                                <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="<?php echo e(route('admin.movie.edit',$movie->id)); ?>">Edit</a></td>
                            </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo $movies->links(); ?>

                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
           
        </div>
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mephim\resources\views/admin/movie/list.blade.php ENDPATH**/ ?>