
<?php $__env->startSection('title'); ?>
Edit Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Category
                            <small>Edit</small>
                        </h1>
                        <?php if(count($errors)): ?>
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($err); ?> <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- /.col-lg-12 -->

                    <div class="col-lg-7" style="padding-bottom:120px">
                        <form action="<?php echo e(route('admin.category.update',$category->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="form-group">
                                <label>Title</label>
                                <input required class="form-control"  name="title" value="<?php echo e($category->title); ?>" />
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <input required class="form-control" name="description" value="<?php echo e($category->description); ?>" />
                            </div>
                            <div class="form-group">
                                <label>Product Status</label>
                                <label class="radio-inline">
                                    <input name="status" <?php if($category->status == 1): ?> checked <?php endif; ?> type="radio">Visible
                                </label>
                                <label class="radio-inline">
                                    <input name="status" <?php if($category->status == 0): ?> checked <?php endif; ?> type="radio">Invisible
                                </label>
                            </div>
                            <button type="submit" class="btn btn-default">Update Add</button>
                            
                        <form>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mephim\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>