
<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">User
                            <small>Edit</small>
                        </h1>
                        <?php if(count($errors)): ?>
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($err); ?> <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- /.col-lg-12 -->
                    <div class="col-lg-7" style="padding-bottom:120px">
                        <form action="<?php echo e(route('admin.user.update',$user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="form-group">
                                <label>Name</label>
                                <input class="form-control" name="name" value="<?php echo e($user->name); ?>" />
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input class="form-control" name="email" readonly value="<?php echo e($user->email); ?>" />
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" name="password" type="password"  />
                            </div>
                            <div class="form-group">
                                <label>Comfirm Password</label>
                                <input class="form-control" name="comfirm_password" type="password" />
                            </div>
                            <div class="form-group">
                                <label>Is Admin</label>
                                <label class="radio-inline">
                                    <input name="is_admin" value="0" <?php if($user->is_admin == 0): ?> checked <?php endif; ?> type="radio">User
                                </label>
                                <label class="radio-inline">
                                    <input name="is_admin" value="1" <?php if($user->is_admin == 1): ?> checked <?php endif; ?> type="radio">Admin
                                </label>
                            </div>
                            <button type="submit" class="btn btn-default">Update</button>
                            
                        <form>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mephim\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>